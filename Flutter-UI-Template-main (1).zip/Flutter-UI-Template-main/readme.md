
# Flutter UI Designs

## Task Management
<img src="/task_management/outputs/op.gif">
<a href="https://github.com/AgnelSelvan/Flutter-UI-Template/tree/main/task_management">Code</a>

#### How to get started?

###### Download the project from Repo

```
git clone https://github.com/AgnelSelvan/Flutter-UI-Template.git
```

```dart
cd task_management
flutter pub get
flutter run
```

## - Crypto Tracker
<img src="/crypto_tracker/outputs/1.gif">
<a href="https://github.com/AgnelSelvan/Flutter-UI-Template/tree/main/crypto_tracker">Code</a>

#### How to get started?

###### Download the project from Repo

```
git clone https://github.com/AgnelSelvan/Flutter-UI-Template.git
```

```dart
cd crypto_tracker
flutter pub get
flutter run
```
