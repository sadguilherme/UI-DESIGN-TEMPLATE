class AppConstants {
  static const String _assets = "assets";

  static const String _svg = _assets + "/svg";
  static const String onBoardingSvg = _svg + "/onboarding.svg";
}
