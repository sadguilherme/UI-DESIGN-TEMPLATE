# Crypto Tracker UI Design

Crypto Tracker Flutter project 🚀.

### Getting Started

###### Download the project from Repo

```
git clone https://github.com/AgnelSelvan/Flutter-UI-Template.git
```

```dart
cd crypto_tracker
flutter pub get
flutter run
```

### Looks 👀

<img src="outputs/1.gif">
<img src="outputs/2.png">
<img src="outputs/1.png">
<img src="outputs/4.png">
<img src="outputs/3.png">