# Task Management UI Design

Task Management Flutter project 🚀.

### Getting Started

###### Download the project from Repo

```
git clone https://github.com/AgnelSelvan/Flutter-UI-Template.git
```

```dart
cd task_management
flutter pub get
flutter run
```

### Looks 👀

<img src="outputs/op.gif">
<img src="outputs/1.png">
<img src="outputs/2.png">
<img src="outputs/3.png">